#!/bin/bash

# Create directories
mkdir -p dist models lib

# Download face-api.js to lib directory
curl -L https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/dist/face-api.min.js -o lib/face-api.min.js

# Download required models
cd models

# SSD Mobilenet model
curl -L https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/ssd_mobilenetv1_model-weights_manifest.json -o ssd_mobilenetv1_model-weights_manifest.json
curl -L https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/ssd_mobilenetv1_model-shard1 -o ssd_mobilenetv1_model-shard1

# Face landmark model
curl -L https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/face_landmark_68_model-weights_manifest.json -o face_landmark_68_model-weights_manifest.json
curl -L https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/face_landmark_68_model-shard1 -o face_landmark_68_model-shard1

# Face recognition model
curl -L https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/face_recognition_model-weights_manifest.json -o face_recognition_model-weights_manifest.json
curl -L https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/face_recognition_model-shard1 -o face_recognition_model-shard1

cd ..

# Create src directory structure if it doesn't exist
mkdir -p src/popup src/options

# Verify face-api.js was downloaded correctly
if [ ! -s lib/face-api.min.js ]; then
    echo "Error: face-api.min.js is empty or missing!"
    exit 1
fi

# Verify model files
for file in models/*.json; do
    if [ ! -s "$file" ]; then
        echo "Error: $file is empty or missing!"
        exit 1
    fi
done

echo "Setup complete!"
