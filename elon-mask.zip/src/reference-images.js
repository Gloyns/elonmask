// Reference images of Elon Musk for face detection
export const elonReferenceImages = [
    // Recent images (2022-2023)
    'https://upload.wikimedia.org/wikipedia/commons/9/99/Elon_Musk_Colorado_2023_%28cropped%29.jpg',
    'https://upload.wikimedia.org/wikipedia/commons/3/34/Elon_Musk_Royal_Society_%28crop2%29.jpg',
    'https://upload.wikimedia.org/wikipedia/commons/8/85/Elon_Musk_Royal_Society_%28crop1%29.jpg',
    
    // Mid-period images (2018-2021)
    'https://upload.wikimedia.org/wikipedia/commons/e/ed/Elon_Musk_Royal_Society.jpg',
    'https://upload.wikimedia.org/wikipedia/commons/4/49/Elon_Musk_2015.jpg',
    'https://upload.wikimedia.org/wikipedia/commons/0/04/Elon_Musk_-_The_Summit_2013.jpg',
    
    // Different angles
    'https://upload.wikimedia.org/wikipedia/commons/b/bb/Elon_Musk_2022.jpg',
    'https://upload.wikimedia.org/wikipedia/commons/d/de/Elon_Musk_at_Tesla_Factory.jpg',
    'https://upload.wikimedia.org/wikipedia/commons/1/13/Elon_Musk_at_SpaceX_%28c%29.jpg',
    
    // Various expressions
    'https://upload.wikimedia.org/wikipedia/commons/4/4b/Elon_Musk_-_TED_Conference.jpg',
    'https://upload.wikimedia.org/wikipedia/commons/8/81/Elon_Musk_at_the_Royal_Society.jpg',
    'https://upload.wikimedia.org/wikipedia/commons/0/08/Elon_Musk_at_MSC_2022_%28cropped%29.jpg'
];

// Function to load and encode images
export async function getEncodedImages() {
    const images = [];
    const loadedUrls = new Set(); // Track which URLs we've already loaded

    for (const url of elonReferenceImages) {
        if (loadedUrls.has(url)) continue; // Skip duplicates
        
        try {
            const response = await fetch(url);
            if (!response.ok) {
                console.warn(`Failed to load image from ${url}: ${response.status} ${response.statusText}`);
                continue;
            }
            
            const blob = await response.blob();
            const base64 = await new Promise((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve(reader.result);
                reader.readAsDataURL(blob);
            });
            
            images.push(base64);
            loadedUrls.add(url);
        } catch (error) {
            console.error('Error loading reference image:', error);
        }
    }

    // Log how many images were successfully loaded
    console.log(`Successfully loaded ${images.length} reference images`);
    return images;
}
