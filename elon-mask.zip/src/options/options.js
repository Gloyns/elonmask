// Show/hide replacement text based on filter mode
function updateVisibility() {
    const filterMode = document.querySelector('input[name="filterMode"]:checked').value;
    const replaceOptions = document.getElementById('replaceOptions');
    replaceOptions.style.display = filterMode === 'replace' ? 'block' : 'none';
}

// Saves options to chrome.storage
function saveOptions() {
    const settings = {
        enabled: document.getElementById('enabled').checked,
        filterMode: document.querySelector('input[name="filterMode"]:checked').value,
        replacementText: document.getElementById('replacementText').value || 'Some Guy',
        filterText: document.getElementById('filterText').checked,
        filterImages: document.getElementById('filterImages').checked,
        filterLinks: document.getElementById('filterLinks').checked,
        companies: {
            tesla: document.getElementById('filterTesla').checked,
            spacex: document.getElementById('filterSpaceX').checked,
            x: document.getElementById('filterX').checked,
            neuralink: document.getElementById('filterNeuralink').checked,
            boringCompany: document.getElementById('filterBoringCompany').checked
        }
    };

    chrome.storage.sync.set({
        settings: settings
    }, function() {
        const status = document.getElementById('status');
        status.textContent = 'Options saved.';
        setTimeout(function() {
            status.textContent = '';
        }, 2000);
    });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restoreOptions() {
    chrome.storage.sync.get({
        settings: {
            enabled: true,
            filterMode: 'replace',
            replacementText: 'Some Guy',
            filterText: true,
            filterImages: true,
            filterLinks: true,
            companies: {
                tesla: true,
                spacex: true,
                x: true,
                neuralink: true,
                boringCompany: true
            }
        }
    }, function(items) {
        const s = items.settings;
        document.getElementById('enabled').checked = s.enabled;
        document.querySelector(`input[name="filterMode"][value="${s.filterMode}"]`).checked = true;
        document.getElementById('replacementText').value = s.replacementText;
        document.getElementById('filterText').checked = s.filterText;
        document.getElementById('filterImages').checked = s.filterImages;
        document.getElementById('filterLinks').checked = s.filterLinks;
        
        // Restore company settings
        document.getElementById('filterTesla').checked = s.companies.tesla;
        document.getElementById('filterSpaceX').checked = s.companies.spacex;
        document.getElementById('filterX').checked = s.companies.x;
        document.getElementById('filterNeuralink').checked = s.companies.neuralink;
        document.getElementById('filterBoringCompany').checked = s.companies.boringCompany;
        
        updateVisibility();
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Get UI elements
    const enabledToggle = document.getElementById('enabled');
    const modeSelect = document.getElementById('mode');
    const customTextInput = document.getElementById('customText');
    const filterTextToggle = document.getElementById('filterText');
    const filterImagesToggle = document.getElementById('filterImages');
    const filterLinksToggle = document.getElementById('filterLinks');
    const filterTeslaToggle = document.getElementById('filterTesla');
    const filterSpaceXToggle = document.getElementById('filterSpaceX');
    const filterXToggle = document.getElementById('filterX');
    const filterNeuralinkToggle = document.getElementById('filterNeuralink');
    const filterBoringCompanyToggle = document.getElementById('filterBoringCompany');
    const saveButton = document.getElementById('save');
    const status = document.getElementById('status');

    // Load settings
    function loadSettings() {
        chrome.storage.sync.get({
            enabled: true,
            mode: 'replace',
            customText: '[REDACTED]',
            filterText: true,
            filterImages: true,
            filterLinks: true,
            companies: {
                tesla: true,
                spacex: true,
                x: true,
                neuralink: true,
                boringCompany: true
            }
        }, (items) => {
            enabledToggle.checked = items.enabled;
            modeSelect.value = items.mode;
            customTextInput.value = items.customText;
            customTextInput.disabled = items.mode !== 'replace';
            
            filterTextToggle.checked = items.filterText;
            filterImagesToggle.checked = items.filterImages;
            filterLinksToggle.checked = items.filterLinks;
            
            filterTeslaToggle.checked = items.companies.tesla;
            filterSpaceXToggle.checked = items.companies.spacex;
            filterXToggle.checked = items.companies.x;
            filterNeuralinkToggle.checked = items.companies.neuralink;
            filterBoringCompanyToggle.checked = items.companies.boringCompany;
        });
    }

    // Save settings
    function saveSettings() {
        chrome.storage.sync.set({
            enabled: enabledToggle.checked,
            mode: modeSelect.value,
            customText: customTextInput.value,
            filterText: filterTextToggle.checked,
            filterImages: filterImagesToggle.checked,
            filterLinks: filterLinksToggle.checked,
            companies: {
                tesla: filterTeslaToggle.checked,
                spacex: filterSpaceXToggle.checked,
                x: filterXToggle.checked,
                neuralink: filterNeuralinkToggle.checked,
                boringCompany: filterBoringCompanyToggle.checked
            }
        }, () => {
            status.textContent = 'Settings saved!';
            status.style.display = 'block';
            setTimeout(() => {
                status.style.display = 'none';
            }, 2000);
        });
    }

    // Event listeners
    modeSelect.addEventListener('change', () => {
        customTextInput.disabled = modeSelect.value !== 'replace';
    });

    saveButton.addEventListener('click', saveSettings);

    // Load settings when page opens
    loadSettings();
});

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);

// Add listener for filter mode change
const filterModeInputs = document.querySelectorAll('input[name="filterMode"]');
filterModeInputs.forEach(input => {
    input.addEventListener('change', updateVisibility);
});
