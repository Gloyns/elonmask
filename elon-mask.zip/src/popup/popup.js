document.addEventListener('DOMContentLoaded', () => {
    // Get UI elements
    const enabledToggle = document.getElementById('enabled');
    const blockModeToggle = document.getElementById('blockMode');
    const replaceModeToggle = document.getElementById('replaceMode');
    const replaceTextInput = document.getElementById('replaceText');
    const blurImagesToggle = document.getElementById('blurImages');

    // Load settings
    chrome.storage.sync.get({
        enabled: true,
        blockMode: false,
        replaceMode: false,
        replaceText: 'Some Guy',
        blurImages: false
    }, (items) => {
        enabledToggle.checked = items.enabled;
        blockModeToggle.checked = items.blockMode;
        replaceModeToggle.checked = items.replaceMode;
        replaceTextInput.value = items.replaceText;
        blurImagesToggle.checked = items.blurImages;
        
        // Update input states
        updateInputStates();
    });

    // Save settings and inject script if enabled
    function saveSettings() {
        const settings = {
            enabled: enabledToggle.checked,
            blockMode: blockModeToggle.checked,
            replaceMode: replaceModeToggle.checked,
            replaceText: replaceTextInput.value,
            blurImages: blurImagesToggle.checked
        };
        
        chrome.storage.sync.set(settings);

        // Inject or remove content script based on enabled state
        if (settings.enabled) {
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                const tab = tabs[0];
                // Inject both CSS and JS
                chrome.scripting.insertCSS({
                    target: { tabId: tab.id },
                    files: ['src/styles.css']
                });
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ['src/content.js']
                });
            });
        }
    }

    // Update input states based on current settings
    function updateInputStates() {
        const isEnabled = enabledToggle.checked;
        const isBlockMode = blockModeToggle.checked;
        
        // Disable all inputs if plugin is disabled
        blockModeToggle.disabled = !isEnabled;
        
        // If block mode is enabled, disable all other options
        replaceModeToggle.disabled = !isEnabled || isBlockMode;
        replaceTextInput.disabled = !isEnabled || isBlockMode || !replaceModeToggle.checked;
        blurImagesToggle.disabled = !isEnabled || isBlockMode;

        // Add visual indication of disabled state
        const disabledClass = 'option-disabled';
        [replaceModeToggle, replaceTextInput, blurImagesToggle].forEach(element => {
            const container = element.closest('.option-group');
            if (container) {
                if (isBlockMode) {
                    container.classList.add(disabledClass);
                } else {
                    container.classList.remove(disabledClass);
                }
            }
        });

        // If block mode is enabled, uncheck other options
        if (isBlockMode) {
            replaceModeToggle.checked = false;
            blurImagesToggle.checked = false;
        }
    }

    // Event listeners
    enabledToggle.addEventListener('change', () => {
        updateInputStates();
        saveSettings();
    });

    blockModeToggle.addEventListener('change', () => {
        updateInputStates();
        saveSettings();
    });

    replaceModeToggle.addEventListener('change', () => {
        updateInputStates();
        saveSettings();
    });

    replaceTextInput.addEventListener('input', saveSettings);
    blurImagesToggle.addEventListener('change', saveSettings);
});
