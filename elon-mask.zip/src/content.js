// Constants for text replacement with word boundaries
const ELON_NAMES = [
    '\\bElon\\s+Musk\\b',  // Match "Elon Musk"
    '\\bElon\\b',          // Match standalone "Elon"
    '\\bMusk\\b',          // Match standalone "Musk"
    '@elonmusk\\b',        // Match Twitter handle
    '\\belonmusk\\b'       // Match username
];

// Get settings from storage or use defaults
async function getSettings() {
    return new Promise((resolve) => {
        chrome.storage.sync.get({
            enabled: true,
            blockMode: false,
            replaceMode: false,
            replaceText: 'Some Guy',
            blurImages: false
        }, (items) => {
            resolve(items);
        });
    });
}

// Build keywords based on settings
function buildKeywords(settings) {
    let keywords = [...ELON_NAMES];
    return keywords;
}

// Check if text contains target keywords
function containsKeywords(text, keywords) {
    const pattern = new RegExp(keywords.join('|'), 'gi');
    return pattern.test(text);
}

// Process text nodes and elements
async function processNode(node, settings, keywords) {
    // Fetch settings if not provided
    if (!settings) {
        settings = await getSettings();
    }
    
    // Fetch keywords if not provided
    if (!keywords) {
        keywords = buildKeywords(settings);
    }
    
    // Skip if this is not an element or text node
    if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.TEXT_NODE) return;
    
    // Skip script and style tags
    if (node.tagName === 'SCRIPT' || node.tagName === 'STYLE') return;
    
    // Handle block mode
    if (settings.blockMode) {
        // For text nodes
        if (node.nodeType === Node.TEXT_NODE) {
            if (containsKeywords(node.textContent, keywords)) {
                if (node.parentElement) {
                    node.parentElement.style.display = 'none';
                    return;
                }
            }
        }
        // For anchor tags
        else if (node.tagName === 'A') {
            if (containsKeywords(node.textContent, keywords) || 
                (node.href && containsKeywords(node.href, keywords))) {
                node.style.display = 'none';
                return;
            }
        }
        // For images
        else if (node.tagName === 'IMG') {
            const altText = node.alt || '';
            const srcText = node.src || '';
            const ariaLabel = node.getAttribute('aria-label') || '';
            
            if (containsKeywords(altText + ' ' + srcText + ' ' + ariaLabel, keywords)) {
                node.style.display = 'none';
                return;
            }
        }
    }
    // Handle replace mode
    else if (settings.replaceMode && node.nodeType === Node.TEXT_NODE) {
        let text = node.textContent;
        const pattern = new RegExp(keywords.join('|'), 'gi');
        if (pattern.test(text)) {
            text = text.replace(pattern, settings.replaceText);
            node.textContent = text;
        }
    }
    
    // Handle image blur
    if (node.tagName === 'IMG' && settings.blurImages) {
        const altText = node.alt || '';
        const srcText = node.src || '';
        const ariaLabel = node.getAttribute('aria-label') || '';
        
        if (containsKeywords(altText + ' ' + srcText + ' ' + ariaLabel, keywords)) {
            node.style.filter = 'blur(10px)';
        }
    }
    
    // Process child nodes
    if (node.childNodes) {
        node.childNodes.forEach(child => processNode(child, settings, keywords));
    }
}

// Main function to process the page
async function processPage() {
    const settings = await getSettings();
    const keywords = buildKeywords(settings);
    
    // Process all text nodes in the document
    const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT,
        null,
        false
    );

    let node;
    while (node = walker.nextNode()) {
        processNode(node, settings, keywords);
    }
}

// Create a MutationObserver to watch for DOM changes
const observer = new MutationObserver((mutations) => {
    mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
            processNode(node, null, null);  // Settings will be fetched inside processNode
        });
    });
});

// Start observing the document with the configured parameters
observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
});

// Run immediately when the script loads
processPage();

// Listen for settings changes
chrome.storage.onChanged.addListener(processPage);
